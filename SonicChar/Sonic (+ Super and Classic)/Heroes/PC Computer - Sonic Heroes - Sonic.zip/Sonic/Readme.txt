Models ripped with GTA DFF IO or Nemesis's Sonic Heroes DFF Import by Shadowth117. Textures ripped with TXD Workshop or ViceTXD also by Shadowth117. No credit needed.

Note: The model import unfortuanately imports UVW's incorrectly so I had to modify them slightly. Because of this, they may be slightly off from the ingame UVW's. If I made a mistake with some UVW editing I apologize.