Metal Sonic from Mario & Sonic at the London Olympic Games 2012 ripped by DogToon64.

If used, give credit to SEGA.

Credit to DogToon64 is optional, but would be nice.