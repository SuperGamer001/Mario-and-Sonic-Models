Super Sonic ripped from Sonic Lost World by HeroArts
Ripping Tools GUI by Nova
