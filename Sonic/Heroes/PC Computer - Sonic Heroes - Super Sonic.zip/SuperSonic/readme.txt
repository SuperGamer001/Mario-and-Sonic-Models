SuperSonic ripped from Sonic Heroes by josh98. No need for credit or anything. Just sayin. :)

Note: The converter does not properly export UVs and they have been modified too work.