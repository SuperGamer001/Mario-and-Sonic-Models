

		#####################
		#		    #
                #   Rip by DatHax.  #
		#   Credit Needed   #
 		#		    #
		#####################

		      -Tutorial-
How to Rip MK7 Models: https://www.youtube.com/watch?v=7GB8chAgCyE
