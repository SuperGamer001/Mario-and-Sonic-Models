Mario from New Super Mario Bros. U ripped by DogToon64.

If used, give credit to Nintendo.

Credit to DogToon64 is optional, but would be nice.